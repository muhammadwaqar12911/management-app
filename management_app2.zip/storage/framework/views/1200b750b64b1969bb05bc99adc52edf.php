

<?php $__env->startSection('title'); ?>
  Sales
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
<h2 class="mt-4">Sales</h2>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active"></li>
</ol>
<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
    </div>
    <div class="card-body">
        <form method="GET" action="<?php echo e(url('sales')); ?>">
            <label for="start_date">Start Date:</label>
            <input type="date" name="start_date" value="<?php echo e($start_date); ?>" id="start_date" required>
            <label for="end_date">End Date:</label>
            <input type="date" name="end_date" value="<?php echo e($end_date); ?>" id="end_date" required>
            <button type="submit">Filter</button>
        </form><br>
        <table id="datatablesSimple">
              <thead>
                  <tr>
                      <th>#</th>
                      <th>Item</th>
                      <th>Item Type</th>
                      <th>Orders</th>
                      <th>Quantity Sold</th>
                      <th>Total Amount</th>
                  </tr>
              </thead>
            <tbody>
                    <?php if(count($items)): ?>
                    <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>
                        <?php echo e($loop->iteration); ?>

                      </td>
                      <td>
                        <?php echo e($i->item); ?>

                      </td>
                      <td>
                        <?php echo e($i->item_type); ?>

                      </td>
                      <td>
                        <?php echo e(count($i->order_items)); ?>

                      </td>
                      <td>
                        <?php echo e($i->order_items_sum_quantity); ?>

                      </td>
                      <td>
                        <?php echo e(number_format($i->order_items_sum_sub_total, 2, '.', ',')); ?>

                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
              </tbody>
              <tfooter>
                    <tr>
                      <th colspan="4" class="text-center">
                      Total :
                      </th>
                      <th>
                        <?php echo e($items->sum('order_items_sum_quantity')); ?>

                      </th>
                      <th>
                        <?php echo e(number_format($items->sum('order_items_sum_sub_total'), 2, '.', ',')); ?>

                      </th>
                    </tr>
              </tfooter>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\management_app\resources\views/admin/sales.blade.php ENDPATH**/ ?>