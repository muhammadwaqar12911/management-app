<?php $__env->startSection('title'); ?>
  Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
<h1 class="mt-4"></h1>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active"></li>
</ol>
<div class="row mx-4">
    <div class="col-md-12"><h3>Orders</h3></div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-4 p-4 shadow" style="border-radius: 10px;">
            <div class="card-body">
                <i class="fas fa-calendar-alt text-white p-3 bg-primary" style="border-radius: 10px;"></i><br>
                <b>Today</b><br>
                <b><?php echo e(count($today)); ?></b><br><br>
                <?php echo e($today->sum('total')); ?> Rs.
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-4 p-4 shadow" style="border-radius: 10px;">
            <div class="card-body">
                <i class="fas fa-calendar-alt text-white p-3 bg-primary" style="border-radius: 10px;"></i><br>
                <b>This Month</b><br>
                <b><?php echo e(count($this_month)); ?></b><br><br>
                <?php echo e($this_month->sum('total')); ?> Rs.
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-4 p-4 shadow" style="border-radius: 10px;">
            <div class="card-body">
                <i class="fas fa-calendar-alt text-white p-3 bg-primary" style="border-radius: 10px;"></i><br>
                <b>This Year</b><br>
                <b><?php echo e(count($this_year)); ?></b><br><br>
                <?php echo e($this_year->sum('total')); ?> Rs.
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-4 p-4 shadow" style="border-radius: 10px;">
            <div class="card-body">
                <i class="fas fa-calendar-alt text-white p-3 bg-primary" style="border-radius: 10px;"></i><br>
                <b>All Time</b><br>
                <b><?php echo e(count($all_the_time)); ?></b><br><br>
                <?php echo e($all_the_time->sum('total')); ?> Rs.
            </div>
        </div>
    </div>
</div>
<div class="row mx-4">
    <div class="col-md-12"><h3>Orders</h3></div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-4 p-4 shadow" style="border-radius: 10px;">
            <div class="card-body">
                <i class="fas fa-chart-line text-white p-3 bg-primary" style="border-radius: 10px;"></i><br>
                <b>Processing</b><br>
                <b><?php echo e(count($processing)); ?></b><br><br>
                <?php echo e($processing->sum('total')); ?> Rs.
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-4 p-4 shadow" style="border-radius: 10px;">
            <div class="card-body">
                <i class="fas fa-check text-white p-3 bg-primary" style="border-radius: 10px;"></i><br>
                <b>Confirmed</b><br>
                <b><?php echo e(count($confirmed)); ?></b><br><br>
                <?php echo e($confirmed->sum('total')); ?> Rs.
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-4 p-4 shadow" style="border-radius: 10px;">
            <div class="card-body">
                <i class="fas fa-pause text-white p-3 bg-primary" style="border-radius: 10px;"></i><br>
                <b>On Holds</b><br>
                <b><?php echo e(count($on_hold)); ?></b><br><br>
                <?php echo e($on_hold->sum('total')); ?> Rs.
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="card mb-4 p-4 shadow" style="border-radius: 10px;">
            <div class="card-body">
                <i class="fas fa-times text-white p-3 bg-primary" style="border-radius: 10px;"></i><br>
                <b>Cancelled</b><br>
                <b><?php echo e(count($cancelled)); ?></b><br><br>
                <?php echo e($cancelled->sum('total')); ?> Rs.
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\management_app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>