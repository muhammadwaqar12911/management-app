

<?php $__env->startSection('title'); ?>
  Customers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
<h2 class="mt-4">Customers</h2>
<ol class="breadcrumb mb-4">
    <li class="breadcrumb-item active"></li>
</ol>
<div class="row">
    <div class="col-md-3"></div>
    <?php if(Session::get('fail')): ?>
    <div class="col-md-6">
        <div class="alert bg-danger text-center" style="color: white;">
            <?php echo e(Session::get('fail')); ?>

        </div>
    </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
    <div class="col-md-6">
        <div class="alert bg-danger text-center" style="color: white;">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($error); ?><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php endif; ?>
    <?php if(Session::get('success')): ?>
    <div class="col-md-6">
        <div class="alert bg-success text-center" style=" color: white;">
            <?php echo e(Session::get('success')); ?>

        </div>
    </div>
    <?php endif; ?> 
    <div class="col-md-3"></div>
</div>

<div class="card mb-4">
    <div class="card-header">
        <i class="fas fa-table me-1"></i>
        <button class="btn text-white bg-primary" style="float: right;" data-bs-toggle="modal" data-bs-target="#exampleModal">
          Add Customer
        </button>
        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                  <form method="post" action="<?php echo e(url('customers')); ?>" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                      <div class="modal-header">
                          <h5 class="modal-title" id="exampleModalLabel">Add Customer</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                      </div>
                      <div class="modal-body p-4">
                          <div class="form-group row">
                              <label>Customer :</label>
                              <input type="text" name="customer" class="form-control mb-2" placeholder="Customer" required="">
                          </div>
                          <div class="form-group row">
                              <label>Customer Type :</label>
                              <input type="text" name="customer_type" class="form-control mb-2" placeholder="Customer Type" required="">
                          </div>
                          <div class="form-group row">
                              <label>Customer Location:</label>
                              <input type="text" name="customer_location" class="form-control mb-2" placeholder="Customer Location" required="">
                          </div>
                          <div class="form-group row">
                              <label>Phone:</label>
                              <input type="text" name="phone" class="form-control mb-2" placeholder="Customer Phone">
                          </div>
                          <div class="form-group row">
                              <label>Note:</label>
                              <textarea name="note" class="form-control mb-2" placeholder="Optional"></textarea>
                          </div>
                      </div>
                      <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          <input type="submit" name="upload" id="upload" class="btn text-white bg-primary" value="Upload">
                      </div>
                  </form>
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <table id="datatablesSimple">
              <thead>
                  <tr>
                      <th>#</th>
                      <th>Customer</th>
                      <th>Customer Type</th>
                      <th>Customer Location</th>
                      <th>Phone</th>
                      <th>Note</th>
                      <th>Action</th>
                  </tr>
              </thead>
            <tbody>
                    <?php if($customers!=null): ?>
                    <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td>
                        <?php echo e($loop->iteration); ?>

                      </td>
                      <td>
                        <?php echo e($c->customer); ?>

                      </td>
                      <td>
                        <?php echo e($c->customer_type); ?>

                      </td>
                      <td>
                        <?php echo e($c->customer_location); ?>

                      </td>
                      <td>
                        <?php echo e($c->phone); ?>

                      </td>
                      <td>
                        <?php echo e($c->note); ?>

                      </td>
                      <td>
                        <a href="" data-bs-toggle="modal" title="view" style="color:gray; text-decoration: none;" data-bs-target="#view<?php echo e($c->id); ?>">
                          <i class="fas fa-eye"></i>
                        </a>
                        <div class="modal fade" id="view<?php echo e($c->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered">
                              <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">View Customer</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                                <div class="modal-body p-4">
                                    <div class="form-group row">
                                        <label>Customer :</label>
                                        <input type="text" name="customer" class="form-control mb-2" readonly="" value="<?php echo e($c->customer); ?>">
                                    </div>
                                    <div class="form-group row">
                                        <label>Customer Type :</label>
                                        <input type="text" name="customer_type" class="form-control mb-2" readonly="" value="<?php echo e($c->customer_type); ?>">
                                    </div>
                                    <div class="form-group row">
                                        <label>Customer Location :</label>
                                        <input type="text" name="customer_location" class="form-control mb-2" readonly="" value="<?php echo e($c->customer_location); ?>">
                                    </div>
                                    <div class="form-group row">
                                        <label>Phone :</label>
                                        <input type="text" name="phone" class="form-control mb-2" readonly="" value="<?php echo e($c->phone); ?>">
                                    </div>
                                    <div class="form-group row">
                                        <label>Note :</label>
                                        <textarea name="note" class="form-control mb-2" readonly=""><?php echo e($c->note); ?></textarea>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                </div>
                              </div>
                          </div>
                        </div>
                        &nbsp&nbsp&nbsp
                        <a href="" data-bs-toggle="modal" title="edit" style="text-decoration: none;" data-bs-target="#edit<?php echo e($c->id); ?>">
                          <i class="fas fa-edit"></i>
                        </a>
                        <div class="modal fade" id="edit<?php echo e($c->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-dialog-centered">
                              <div class="modal-content">
                                <form method="post" action="<?php echo e(url('customers', $c->id)); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Edit Customer</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body p-4">
                                        <div class="form-group row">
                                            <label>Customer :</label>
                                            <input type="text" name="customer" class="form-control mb-2" required="" value="<?php echo e($c->customer); ?>">
                                        </div>
                                        <div class="form-group row">
                                            <label>Customer Type :</label>
                                            <input type="text" name="customer_type" class="form-control mb-2" required="" value="<?php echo e($c->customer_type); ?>">
                                        </div>
                                        <div class="form-group row">
                                            <label>Customer Location :</label>
                                            <input type="text" name="customer_location" class="form-control mb-2" required="" value="<?php echo e($c->customer_location); ?>">
                                        </div>
                                        <div class="form-group row">
                                            <label>Phone :</label>
                                            <input type="text" name="phone" class="form-control mb-2" value="<?php echo e($c->phone); ?>">
                                        </div>
                                        <div class="form-group row">
                                            <label>Note :</label>
                                            <textarea name="note" class="form-control mb-2" placeHolder="optional"><?php echo e($c->note); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        <input type="submit" name="upload" id="upload" class="btn text-white btn-primary" value="Update">
                                    </div>
                                </form>
                              </div>
                          </div>
                        </div>
                        <form style="display: inline; text-decoration: none;" method="post" action="<?php echo e(url('customers',$c->id)); ?>" enctype="multipart/form-data">
                          <?php echo method_field('Delete'); ?>
                          <?php echo csrf_field(); ?>
                          <button title="delete" class="btn" style="color:red;">
                            <i class="fas fa-trash-alt"></i>
                          </button>
                        </form>
                      </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
              </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\management_app\resources\views/admin/customers.blade.php ENDPATH**/ ?>